__author__ = "Inada Naoki <songofacandy@gmail.com>"
__version__ = "2.2.0"
version_info = (2, 2, 0, "final", 0)
